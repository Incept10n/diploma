# Chart: Cluster Shield

All notable changes to this chart will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Please note that it's automatically updated vía github actions.
Manual edits are supported only below '## Change Log' and should be used
exclusively to fix incorrect entries and not to add new ones.

## Change Log
# v1.21.1
### Bug Fixes
* [6970f804](https://github.com/sysdiglabs/charts/commit/6970f8040ecec4dd015658955466630374654a4d): remove unused param value ([#2578](https://github.com/sysdiglabs/charts/issues/2578))
# v1.21.0
### Chores
* **cluster-shield** [bb44e702](https://github.com/sysdiglabs/charts/commit/bb44e702d261e88dd72e4343eec7cd85593ecaf1): Automatic bump to version 1.21.0 ([#2565](https://github.com/sysdiglabs/charts/issues/2565))
# v1.20.0
### New Features
* **shield,cluster-shield,sysdig-deploy** [6ef584e6](https://github.com/sysdiglabs/charts/commit/6ef584e656c96efc945b6f970ba0032c99fecb12): release cluster-shield 1.20.0 ([#2541](https://github.com/sysdiglabs/charts/issues/2541))
# v1.19.0
### Chores
* **cluster-shield** [e530ee7c](https://github.com/sysdiglabs/charts/commit/e530ee7c37f865942611de12294e37f10032837a): Automatic bump to version 1.19.0 ([#2518](https://github.com/sysdiglabs/charts/issues/2518))
# v1.18.2
### Chores
* **cluster-shield** [82aacf62](https://github.com/sysdiglabs/charts/commit/82aacf624774030e82ae7edcb01489657683bba2): Automatic bump to version 1.18.1 ([#2490](https://github.com/sysdiglabs/charts/issues/2490))
# v1.18.1
### Bug Fixes
* **shield,cluster-shield** [970ff5ae](https://github.com/sysdiglabs/charts/commit/970ff5ae99ac97d83f1a6e3475e839fd1bd6bf3e): fixed shield and cluster-shield charts for AC with image-signature only ([#2448](https://github.com/sysdiglabs/charts/issues/2448))
# v1.18.0
### New Features
* **shield,cluster-shield,sysdig-deploy** [4154614f](https://github.com/sysdiglabs/charts/commit/4154614fc8123a56be42b17f6680a335a260edad): release cluster-shield 1.18.0 ([#2451](https://github.com/sysdiglabs/charts/issues/2451))
# v1.17.0
### Chores
* **cluster-shield,shield,sysdig-deploy** [09167785](https://github.com/sysdiglabs/charts/commit/091677853e925d1a07bd27a366e0166726d8139a): release cluster-shield 1.17.0 ([#2422](https://github.com/sysdiglabs/charts/issues/2422))
# v1.16.1
### Chores
* **shield,cluster-shield** [dc7f70f4](https://github.com/sysdiglabs/charts/commit/dc7f70f4816d5c9463d09f51c4acfb3d21504c74): Automatic bump to version 1.16.1 ([#2412](https://github.com/sysdiglabs/charts/issues/2412))
# v1.16.0
### Chores
* **cluster-shield,sysdig-deploy,shield** [f2021042](https://github.com/sysdiglabs/charts/commit/f2021042c3f4e644263444c0ae6026fb2734a9e8): release cluster-shield 1.16.0 ([#2397](https://github.com/sysdiglabs/charts/issues/2397))
# v1.15.0
### Chores
* **shield,common,sysdig-deploy,admission-controller,agent,cluster-scanner,cluster-shield,kspm-collector,node-analyzer,rapid-response** [1b992fbc](https://github.com/sysdiglabs/charts/commit/1b992fbc14ffd5b1f63be3896ee40deb5a858d06): bump cluster-shield to 1.15.0 ([#2360](https://github.com/sysdiglabs/charts/issues/2360))
# v1.14.0
### Chores
* **cluster-shield,sysdig-deploy** [43070907](https://github.com/sysdiglabs/charts/commit/4307090721541412594aab33a8cf3120b44c22d7): Automatic bump to version 1.14.0 ([#2333](https://github.com/sysdiglabs/charts/issues/2333))
# v1.13.0
### Chores
* **cluster-shield,shield,sysdig-deploy** [d0784daf](https://github.com/sysdiglabs/charts/commit/d0784dafa3ec6651de22632232cfd0f5e9547c4b): Automatic bump to version 1.13.0 ([#2297](https://github.com/sysdiglabs/charts/issues/2297))
# v1.12.1
### Chores
* **shield,cluster-shield,sysdig-deploy** [376fca85](https://github.com/sysdiglabs/charts/commit/376fca85c6f942c2ddc9b494211b29bdddd9b257): Automatic bump to version 1.12.1 ([#2278](https://github.com/sysdiglabs/charts/issues/2278))
# v1.12.0
### Chores
* **cluster-shield,sysdig-deploy,shield** [d76fccf8](https://github.com/sysdiglabs/charts/commit/d76fccf80af45038011114192624b37e81411c64): Automatic bump to version 1.12.0 ([#2272](https://github.com/sysdiglabs/charts/issues/2272))
# v1.10.0
### Chores
* **cluster-shield** [8df60680](https://github.com/sysdiglabs/charts/commit/8df60680c6ca6888277c60efbdac2fa2532f2810): Automatic bump to version 1.10.0 ([#2208](https://github.com/sysdiglabs/charts/issues/2208))
# v1.9.1
### Chores
* **sysdig-deploy,cluster-shield** [06778ccb](https://github.com/sysdiglabs/charts/commit/06778ccbf00f193d4a0e5a423321c807c39fe005): Automatic bump to version 1.9.1 ([#2187](https://github.com/sysdiglabs/charts/issues/2187))
# v1.9.0
### Chores
* **cluster-shield,shield,sysdig-deploy** [638ca265](https://github.com/sysdiglabs/charts/commit/638ca265259e0d350f92e75da063924f00de1bd3): Automatic bump to version 1.9.0 ([#2173](https://github.com/sysdiglabs/charts/issues/2173))
# v1.8.3
### Bug Fixes
* **agent,cluster-shield,node-analyzer,shield,kspm-collector,admission-controller,rapid-response** [f71edde3](https://github.com/sysdiglabs/charts/commit/f71edde32e4f1894bf015b94fe55f4d720b79513): remove unused allowedUnsafeSysctls constraint ([#2005](https://github.com/sysdiglabs/charts/issues/2005))
# v1.8.2
### Chores
* **cluster-shield,shield,sysdig-deploy** [b087bfa5](https://github.com/sysdiglabs/charts/commit/b087bfa5fba13e559a6a9ffbc6c01bd1ca00622b): Automatic bump to version 1.8.2 ([#2168](https://github.com/sysdiglabs/charts/issues/2168))
# v1.8.1
### Chores
* **cluster-shield,shield,sysdig-deploy** [a0a64555](https://github.com/sysdiglabs/charts/commit/a0a645551a9718380cd51ab9ad428b1b660c3528): Automatic bump to version 1.8.1 ([#2164](https://github.com/sysdiglabs/charts/issues/2164))
# v1.8.0
### Chores
* **cluster-shield,sysdig-deploy** [13050097](https://github.com/sysdiglabs/charts/commit/1305009755b646fbd8e869aaca470ff4406f726c): Automatic bump to version 1.8.0 ([#2140](https://github.com/sysdiglabs/charts/issues/2140))
# v1.7.1
### Chores
* **cluster-shield,sysdig-deploy,shield** [9edcb32f](https://github.com/sysdiglabs/charts/commit/9edcb32f47d5b3338b15f229d6eadc2cece9492e): Automatic bump to version 1.7.1 ([#2104](https://github.com/sysdiglabs/charts/issues/2104))
# v1.7.0
### Chores
* **cluster-shield,sysdig-deploy** [fda74488](https://github.com/sysdiglabs/charts/commit/fda744888d283c69a65d883cb4528dc270061c60): Automatic bump to version 1.7.0 ([#2101](https://github.com/sysdiglabs/charts/issues/2101))
# v1.6.0
### Chores
* **cluster-shield,sysdig-deploy** [7b050fb3](https://github.com/sysdiglabs/charts/commit/7b050fb38e47d2fdb780ee5870e535bb046fbfc1): bump cluster-shield to version 1.6.0 ([#2073](https://github.com/sysdiglabs/charts/issues/2073))
# v1.5.1
### Chores
* **cluster-shield** [2c0505ce](https://github.com/sysdiglabs/charts/commit/2c0505ce3fcd19f1beda92eda89bcee96622c729): Automatic bump to version 1.5.1 ([#2036](https://github.com/sysdiglabs/charts/issues/2036))
# v1.5.0
### Chores
* **cluster-shield,sysdig-deploy** [0b00754b](https://github.com/sysdiglabs/charts/commit/0b00754b0e3e24a7a9ce906180f019e268036423): bump cluster-shield to version 1.5.0 ([#2015](https://github.com/sysdiglabs/charts/issues/2015))
# v1.4.2
### Bug Fixes
* **cluster-shield** [f4262f0a](https://github.com/sysdiglabs/charts/commit/f4262f0aa956aa5042ef253765efa56f40e4de40): fix type casting for ssl.verify ([#1988](https://github.com/sysdiglabs/charts/issues/1988))
# v1.4.1
### Chores
* **cluster-shield** [a2e408c9](https://github.com/sysdiglabs/charts/commit/a2e408c941b097fea0a6b36f88ec9de7b30a7f9d): Automatic bump to version 1.4.0 ([#1977](https://github.com/sysdiglabs/charts/issues/1977))
# v1.4.0
### Chores
* **cluster-shield,sysdig-deploy,shield** [f718a4e7](https://github.com/sysdiglabs/charts/commit/f718a4e7b6164a306919531120ad9cbf938c6424): bump cluster-shield to version 1.4.0 ([#1967](https://github.com/sysdiglabs/charts/issues/1967))
# v1.3.1
### Chores
* **cluster-shield** [c37ba855](https://github.com/sysdiglabs/charts/commit/c37ba8559c34eb3029b99f0b51aa6571d9538e22): Automatic bump to version 1.3.1 ([#1928](https://github.com/sysdiglabs/charts/issues/1928))
# v1.3.0
### Chores
* **cluster-shield** [b8b27211](https://github.com/sysdiglabs/charts/commit/b8b27211bc7d54f9be98ef710030351e8d7352c8): Automatic bump to version 1.3.0 ([#1909](https://github.com/sysdiglabs/charts/issues/1909))
# v1.2.0
### Chores
* **cluster-shield,sysdig-deploy** [d1957eab](https://github.com/sysdiglabs/charts/commit/d1957eab33d9e2f3c22846dc03887bbf43f0b247):  bump cluster-shield to version 1.2.0 ([#1874](https://github.com/sysdiglabs/charts/issues/1874))
# v1.1.2
### Chores
* **cluster-shield** [dcc7db9d](https://github.com/sysdiglabs/charts/commit/dcc7db9d873ff37df99763a1e2e9d1abdf9b31f3): Automatic bump to version 1.1.2 ([#1842](https://github.com/sysdiglabs/charts/issues/1842))
# v1.1.1
### Chores
* **cluster-shield** [e2fcdd28](https://github.com/sysdiglabs/charts/commit/e2fcdd28403a94cb28a31769ea5c51b36ee75ce0): Automatic bump to version 1.1.1 ([#1807](https://github.com/sysdiglabs/charts/issues/1807))
# v1.1.0
### Chores
* **cluster-shield** [7c86a283](https://github.com/sysdiglabs/charts/commit/7c86a283f1ec252ca280f11457c5e6825dd09d10): Automatic bump to version 1.1.0 ([#1798](https://github.com/sysdiglabs/charts/issues/1798))
# v1.0.5
### Chores
* **agent,cluster-shield,sysdig-deploy,rapid-response,kspm-collector,cluster-scanner** [87059f19](https://github.com/sysdiglabs/charts/commit/87059f1992b6bf1c133ef96937ea2da90fa7d8a1): bump helm-unittest to v0.5.1 ([#1785](https://github.com/sysdiglabs/charts/issues/1785))
# v1.0.4
### Bug Fixes
* **cluster-shield** [de790816](https://github.com/sysdiglabs/charts/commit/de7908164fad4ef145722e254c0259bed5fc5701): global.sslVerifyCertificate was not correctly used ([#1793](https://github.com/sysdiglabs/charts/issues/1793))
# v1.0.3
### Bug Fixes
* **cluster-shield** [92cfbb00](https://github.com/sysdiglabs/charts/commit/92cfbb001d1c790b238d3efc9659c4b36a20156d): Change secureApiTokenSecret key name ([#1790](https://github.com/sysdiglabs/charts/issues/1790))
# v1.0.2
### Chores
* **cluster-shield** [0c3097f9](https://github.com/sysdiglabs/charts/commit/0c3097f9f32e7fefea4444c3c026951ac4fb10ac): Automatic bump to version 1.0.1 ([#1782](https://github.com/sysdiglabs/charts/issues/1782))
# v1.0.1
### Chores
* **cluster-shield** [0773b4cb](https://github.com/sysdiglabs/charts/commit/0773b4cb68b506acfa5b4869ba6697349e161231): Automatic bump to version 1.0.1 ([#1779](https://github.com/sysdiglabs/charts/issues/1779))
# v1.0.0
### Chores
* **cluster-shield** [e615245d](https://github.com/sysdiglabs/charts/commit/e615245dcfdf26c0261c5a02dd1123e7c7b7fe6e): Automatic bump to version 1.0.0 ([#1771](https://github.com/sysdiglabs/charts/issues/1771))
# v0.11.0
### New Features
* **cluster-shield,sysdig-deploy** [8f6dfaaf](https://github.com/sysdiglabs/charts/commit/8f6dfaaf4b8472439be38560db5bf0d3b300f86f): bump cluster-shield to v0.11.0 and integrate it in sysdig-deploy ([#1764](https://github.com/sysdiglabs/charts/issues/1764))
# v0.10.2
### Bug Fixes
* **cluster-shield** [4951bd68](https://github.com/sysdiglabs/charts/commit/4951bd68f0643db5529b4c6b4f0822c854ae27fd): add missing CHANGELOG file and bump version ([#1728](https://github.com/sysdiglabs/charts/issues/1728))
### Chores
* **cluster-shield** [ccde92b3](https://github.com/sysdiglabs/charts/commit/ccde92b3a672445f065d3612772e4105b9331049): Automatic bump to version 0.10.1 ([#1726](https://github.com/sysdiglabs/charts/issues/1726))
# v0.10.1
### Chores
* **cluster-shield** [ccde92b](https://github.com/sysdiglabs/charts/commit/ccde92b3a672445f065d3612772e4105b9331049): Automatic bump to version 0.10.1 ([#1726](https://github.com/sysdiglabs/charts/issues/1726))
