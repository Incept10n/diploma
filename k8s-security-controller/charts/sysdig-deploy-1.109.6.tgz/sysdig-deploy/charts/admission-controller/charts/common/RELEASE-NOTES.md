# What's Changed

### New Features
- **shield,sysdig-deploy,common** [5415a9d0](https://github.com/sysdiglabs/charts/commit/5415a9d0dff64fa3f692b75e462961249684ba63): add in-che region support [SMAGENT-10149] ([#2550](https://github.com/sysdiglabs/charts/issues/2550))
#### Full diff: https://github.com/sysdiglabs/charts/compare/common-1.4.0...common-1.5.0
